%function Ts=subsamp(T,scale)
%
% Subsample T3 tensor with 
% a factor SCALE
%

function Ts=tensSubsamp(T,scale)

[df,ys,xs] = size(T);

if (df~=3)
    error('Argument <T> should be a T3 tensor');
end

T1=subsamp(squeeze(T(1,:,:)),scale);
Ts=zeros([3 size(T1)]);
Ts(1,:,:)=T1;
Ts(2,:,:)=subsamp(squeeze(T(2,:,:)),scale);
Ts(3,:,:)=subsamp(squeeze(T(3,:,:)),scale);


%function sigOut = syntFilt2D2(S,C,ahp);
%
% Double variant
%
%  This routine will combine a set of fixed filter responses
%  into an adaptive filter response using the control tensor C.
%  C should contain tensors in T3 format.
%
%  S       should contain the precomputed fixed filter responses.
%  AHP     is the amplification factor for the high-pass content
%          of the signal
%
% See "Signal Processing For Computer Vision" section 10.4
%
%Per-Erik Forssen, 1998
%
function sigOut = syntFilt2D2(S,C,ahp);

[v1 v2 v3]=size(S);
[dummy ysz xsz]=size(C);
if((ysz~=v1)|(xsz~=v2))
   s=sprintf('Usage:<sigOut> = syntFilt2D(<S>,<C>,<ahp>)\n\nthe supplied parameters S and C are not compatible.');
   error(s);
end;

%
% Set up filter directions and compute dual tensors
%

disp('Building dual tensors...');
n1=[1 0]';
n2=1/sqrt(2)*[1 1]';
n3=[0 1]';
n4=1/sqrt(2)*[-1 1]';
I=diag([1,1]);
% Dual tensors
Md1=4/3*n1*n1'-I/3;
M1=Md1([1 4 3])';
Md2=4/3*n2*n2'-I/3;
M2=Md2([1 4 3])';
Md3=4/3*n3*n3'-I/3;
M3=Md3([1 4 3])';
Md4=4/3*n4*n4'-I/3;
M4=Md4([1 4 3])';
Md=([M1 M2 M3 M4]'*diag([1,1,2]))';

%
% Perform the filter synthesis
%

disp('Performing filter synthesis...');
slp=reshape(S(:,:,1),[xsz*ysz,1]);

S=reshape(S(:,:,2:5),[xsz*ysz,4]);

%
% Convert C into a [3,xsz*ysz] matrix
% and compute the filter coefficients ck

Cr=reshape(C,[3 xsz*ysz]);
ck=Cr'*Md;

s=min(255,max(0,slp+ahp*sum((ck.*S)')'));
sigOut=reshape(s,[ysz,xsz]);


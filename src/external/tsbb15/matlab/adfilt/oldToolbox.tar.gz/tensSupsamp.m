%function Tb=tensSupsamp(T,pads)
%
% Super sample T3 tensor T
%

function Tb=tensSupsamp(T,pads)

df=size(T,1);


if (df~=3)
    error('Argument <T> should be a T3 tensor.');
end

Tb(1,:,:)=supsamp(squeeze(T(1,:,:)),pads);
Tb(2,:,:)=supsamp(squeeze(T(2,:,:)),pads);
Tb(3,:,:)=supsamp(squeeze(T(3,:,:)),pads);


%function bigTitle(tit)
%
% Sets a title in current figure
% and displays it.
%

function bigTitle(tit)

title(tit,'FontSize',18,'FontName','Times');
drawnow;
